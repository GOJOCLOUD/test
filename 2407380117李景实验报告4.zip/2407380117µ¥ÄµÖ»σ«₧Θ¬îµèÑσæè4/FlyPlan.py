from collections import defaultdict
import heapq

class FlightGraph:
    def __init__(self):
        self.cities = {}
        self.adj_list = defaultdict(list)
        self.city_to_index = {}
        self.index_to_city = {}

    def add_city(self, index, name):
        self.city_to_index[name] = index
        self.index_to_city[index] = name

    def add_flight(self, city1, city2, distance):
        idx1 = self.city_to_index[city1]
        idx2 = self.city_to_index[city2]
        self.adj_list[idx1].append((idx2, distance))
        self.adj_list[idx2].append((idx1, distance))

    def dijkstra(self, start_idx, end_idx=None):
        distances = {i: float('inf') for i in self.city_to_index.values()}
        distances[start_idx] = 0
        previous = {i: None for i in self.city_to_index.values()}
        pq = [(0, start_idx)]
        visited = set()

        while pq:
            current_dist, current = heapq.heappop(pq)
            
            if current in visited:
                continue
            visited.add(current)
            
            if end_idx is not None and current == end_idx:
                break
            
            for neighbor, weight in self.adj_list[current]:
                if neighbor not in visited:
                    new_dist = current_dist + weight
                    if new_dist < distances[neighbor]:
                        distances[neighbor] = new_dist
                        previous[neighbor] = current
                        heapq.heappush(pq, (new_dist, neighbor))
        
        return distances, previous

    def get_shortest_path(self, start_city, end_city):
        start_idx = self.city_to_index[start_city]
        end_idx = self.city_to_index[end_city]
        
        distances, previous = self.dijkstra(start_idx, end_idx)
        
        if distances[end_idx] == float('inf'):
            return None, float('inf')
        
        path = []
        current = end_idx
        while current is not None:
            path.append(self.index_to_city[current])
            current = previous[current]
        
        path.reverse()
        return path, distances[end_idx]

    def traveling_salesman(self, start_city):
        start_idx = self.city_to_index[start_city]
        cities = list(self.city_to_index.keys())
        cities.remove(start_city)
        
        min_distance = float('inf')
        best_path = []
        
        from itertools import permutations
        
        for perm in permutations(cities):
            total_distance = 0
            path = [start_city]
            current = start_city
            
            for next_city in perm:
                path_segment, distance = self.get_shortest_path(current, next_city)
                if path_segment is None:
                    total_distance = float('inf')
                    break
                total_distance += distance
                current = next_city
            
            if total_distance < min_distance:
                min_distance = total_distance
                best_path = path + list(perm)
        
        return best_path, min_distance

    def print_graph(self):
        print("航班线路图:")
        print("-" * 50)
        for idx in sorted(self.index_to_city.keys()):
            city = self.index_to_city[idx]
            edges = self.adj_list[idx]
            edge_str = ", ".join([f"{self.index_to_city[v]}({w}km)" for v, w in edges])
            print(f"{city}: {edge_str}")
        print("-" * 50)

def main():
    print("=" * 60)
    print("航班问题解决方案")
    print("=" * 60)
    
    flight_graph = FlightGraph()
    
    flight_graph.add_city(0, "上海")
    flight_graph.add_city(1, "北京")
    flight_graph.add_city(2, "南京")
    flight_graph.add_city(3, "大连")
    flight_graph.add_city(4, "哈尔滨")
    flight_graph.add_city(5, "昆明")
    flight_graph.add_city(6, "西安")
    flight_graph.add_city(7, "青岛")
    
    flight_graph.add_flight("上海", "北京", 900)
    flight_graph.add_flight("上海", "南京", 500)
    flight_graph.add_flight("北京", "南京", 600)
    flight_graph.add_flight("北京", "大连", 1000)
    flight_graph.add_flight("南京", "哈尔滨", 1700)
    flight_graph.add_flight("南京", "昆明", 1900)
    flight_graph.add_flight("大连", "昆明", 1000)
    flight_graph.add_flight("大连", "西安", 1000)
    flight_graph.add_flight("大连", "青岛", 1000)
    flight_graph.add_flight("昆明", "青岛", 1500)
    
    print("\n各城市之间航班线路及其里程表:")
    flight_graph.print_graph()
    
    print("\n" + "=" * 60)
    print("问题(1): 从上海出发，玩遍所有城市的最短路线")
    print("=" * 60)
    
    start_city = "上海"
    best_path, min_distance = flight_graph.traveling_salesman(start_city)
    
    if min_distance == float('inf'):
        print("无法找到遍历所有城市的路线（图不连通）")
    else:
        print(f"最短旅游路线 (总路程: {min_distance} 公里):")
        print(" -> ".join(best_path))
        print(f"\n总路程: {min_distance} 公里")
    
    print("\n" + "=" * 60)
    print("问题(2): 从上海到各目的地的最短购票方案")
    print("=" * 60)
    
    start_city = "上海"
    destinations = ["北京", "南京", "大连", "哈尔滨", "昆明", "西安", "青岛"]
    
    for dest in destinations:
        path, distance = flight_graph.get_shortest_path(start_city, dest)
        if path is not None:
            print(f"\n上海 -> {dest}:")
            print(f"  最短路径: {' -> '.join(path)}")
            print(f"  总路程: {distance} 公里")
        else:
            print(f"\n上海 -> {dest}:")
            print(f"  无法到达")

if __name__ == "__main__":
    main()
