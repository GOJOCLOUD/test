from collections import deque, defaultdict

class Graph:
    def __init__(self, num_vertices):
        self.num_vertices = num_vertices
        self.adj_list = defaultdict(list)

    def add_edge(self, u, v, weight):
        self.adj_list[u].append((v, weight))
        self.adj_list[v].append((u, weight))

    def print_adj_list(self):
        print("邻接表存储结构:")
        print("-" * 40)
        for vertex in sorted(self.adj_list.keys()):
            edges = self.adj_list[vertex]
            edge_str = ", ".join([f"({v}, {w})" for v, w in edges])
            print(f"顶点 {vertex}: {edge_str}")
        print("-" * 40)

    def dfs(self, start):
        visited = set()
        result = []
        
        def dfs_util(v):
            visited.add(v)
            result.append(v)
            for neighbor, _ in sorted(self.adj_list[v], key=lambda x: x[0]):
                if neighbor not in visited:
                    dfs_util(neighbor)
        
        dfs_util(start)
        return result

    def bfs(self, start):
        visited = set([start])
        queue = deque([start])
        result = []
        
        while queue:
            vertex = queue.popleft()
            result.append(vertex)
            for neighbor, _ in sorted(self.adj_list[vertex], key=lambda x: x[0]):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
        
        return result

    def prim_mst(self, start):
        mst_edges = []
        total_cost = 0
        visited = set([start])
        edges = []
        
        for neighbor, weight in self.adj_list[start]:
            edges.append((weight, start, neighbor))
        
        while len(visited) < self.num_vertices:
            edges.sort()
            found = False
            
            for i, (weight, u, v) in enumerate(edges):
                if v not in visited:
                    visited.add(v)
                    mst_edges.append((u, v, weight))
                    total_cost += weight
                    for neighbor, w in self.adj_list[v]:
                        if neighbor not in visited:
                            edges.append((w, v, neighbor))
                    edges.pop(i)
                    found = True
                    break
            
            if not found:
                break
        
        return mst_edges, total_cost

def main():
    print("=" * 50)
    print("带权无向图操作程序")
    print("=" * 50)
    
    g = Graph(6)
    
    g.add_edge(0, 1, 6)
    g.add_edge(0, 2, 1)
    g.add_edge(0, 3, 5)
    g.add_edge(1, 2, 5)
    g.add_edge(1, 4, 3)
    g.add_edge(2, 3, 5)
    g.add_edge(2, 4, 6)
    g.add_edge(2, 5, 4)
    g.add_edge(3, 5, 2)
    g.add_edge(4, 5, 6)
    
    print("\n① 带权无向图已构建完成")
    print("图结构:")
    print("顶点: 0, 1, 2, 3, 4, 5")
    print("边及权重:")
    print("  0-1 (6), 0-2 (1), 0-3 (5)")
    print("  1-2 (5), 1-4 (3)")
    print("  2-3 (5), 2-4 (6), 2-5 (4)")
    print("  3-5 (2)")
    print("  4-5 (6)")
    
    print("\n② 输出邻接表存储结构")
    g.print_adj_list()
    
    print("\n③ 图的遍历")
    start_vertex = 0
    dfs_result = g.dfs(start_vertex)
    print(f"深度优先遍历(DFS)序列 (从顶点 {start_vertex} 开始):")
    print(" -> ".join(map(str, dfs_result)))
    
    bfs_result = g.bfs(start_vertex)
    print(f"\n广度优先遍历(BFS)序列 (从顶点 {start_vertex} 开始):")
    print(" -> ".join(map(str, bfs_result)))
    
    print("\n④ Prim算法求最小生成树")
    mst_edges, total_cost = g.prim_mst(start_vertex)
    print(f"最小生成树 (从顶点 {start_vertex} 开始):")
    print("边及权重:")
    for u, v, w in mst_edges:
        print(f"  {u} -- {v} (权重: {w})")
    print(f"\n最小生成树的总代价: {total_cost}")

if __name__ == "__main__":
    main()
